﻿class Book : Document
{
    protected string author;

    public Book(string newTitle, string newAuthor, string newLocation)
    {
        title = newTitle;
        author = newAuthor;
        location = newLocation;
    }

    public void SetAuthor(string newAuthor)
    {
        author = newAuthor;
    }

    public string GetAuthor()
    {
        return author;
    }
}
