﻿class Document
{
    protected string title;
    protected string location;

    public Document()
    {
        title = "Untitled";
        location = "Unknown location";
    }

    public Document(string newTitle, string newLocation)
    {
        title = newTitle;
        location = newLocation;
    }

    public void SetTitle(string newTitle)
    {
        title = newTitle;
    }

    public void SetLocation(string newLocation)
    {
        location = newLocation;
    }

    public string GetTitle()
    {
        return title;
    }

    public string GetLocation()
    {
        return location;
    }
}

