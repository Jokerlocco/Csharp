﻿using System;

class BookTest
{
    static void Main(string[] args)
    {
        Book b = new Book("It", "Stephen King", "A1");
        Console.WriteLine(b.GetTitle() + ", " +
            b.GetAuthor() + ": " +
            b.GetLocation());
    }
}
