﻿using System;

class ConsoleSprite : Sprite
{
    protected char image;

    public ConsoleSprite()
    {
        image = 'A';
    }

    public void SetImage(char i) { image = i; }
    public char GetImage() { return image; }

    public new void Draw()
    {
        Console.SetCursorPosition(x / 15, y / 30);
        Console.WriteLine(image);
    }
}

