﻿using System;

class SpriteTest
{
    static void Main(string[] args)
    {
        ConsoleSprite mySprite = new ConsoleSprite();
        mySprite.MoveTo(100, 150);
        mySprite.SetY(160);
        Console.WriteLine(mySprite.GetX());
        mySprite.SetImage('X');
        mySprite.Draw();
    }
}
