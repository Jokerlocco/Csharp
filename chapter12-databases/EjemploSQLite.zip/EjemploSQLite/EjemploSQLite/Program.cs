﻿using System;
using System.Data.SQLite;

namespace EjemploSQLite
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Creando la base de datos...");

            SQLiteConnection conexion =
              new SQLiteConnection
              ("Data Source=ejemplo01.sqlite;Version=3;New=True;Compress=True;");
            conexion.Open();

            // Creamos la tabla
            string creacion = "create table personas ("
               + " nombre varchar(20),direccion varchar(40),edad int);";
            SQLiteCommand cmd = new SQLiteCommand(creacion, conexion);
            cmd.ExecuteNonQuery();

            // ...

            // Y finalmente cerramos la conexión
            conexion.Close();

            Console.WriteLine("Creada.");

        }
    }
}
