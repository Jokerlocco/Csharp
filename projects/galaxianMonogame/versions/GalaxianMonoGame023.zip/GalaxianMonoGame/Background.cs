﻿// Galaxian SDL

// Version + Date   Author + Changes
// --------------   --------------------------------------
// 009, 21-Feb-19   Nacho: Empty skeleton

class Background : Sprite
{
}
