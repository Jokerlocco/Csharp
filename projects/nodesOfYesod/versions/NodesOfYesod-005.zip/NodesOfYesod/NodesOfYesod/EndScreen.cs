﻿/**
 * EndScreen.cs - Nodes Of Yesod, End screen
 * 
 * Changes:
 * 0.03, 14-01-2019: End screen created (empty skeleton)
 */

class EndScreen
{
    public void Run()
    {
        // TO DO
    }
}
