﻿/**
 * CreditsScreen.cs - Nodes Of Yesod, Credits screen
 * 
 * Changes:
 * 0.03, 14-01-2019: Credits screen created (empty skeleton)
 */

class CreditsScreen
{
    public void Run()
    {
        // TO DO
    }
}

