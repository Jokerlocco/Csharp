﻿/**
 * HelpScreen.cs - Nodes Of Yesod, Help screen
 * 
 * Changes:
 * 0.03, 14-01-2019: Help screen created (empty skeleton)
 */

class HelpScreen
{
    public void Run()
    {
        // TO DO
    }
}

