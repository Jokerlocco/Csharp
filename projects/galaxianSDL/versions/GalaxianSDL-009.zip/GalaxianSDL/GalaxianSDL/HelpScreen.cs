﻿// Galaxian SDL

// Version + Date   Author + Changes
// --------------   --------------------------------------
// 009, 21-Feb-19   Nacho: Empty skeleton

class HelpScreen
{
    public HelpScreen()
    {
    }

    public void Run()
    {
        // TO DO: Display some Help. Wait for R to return.
    }
}

