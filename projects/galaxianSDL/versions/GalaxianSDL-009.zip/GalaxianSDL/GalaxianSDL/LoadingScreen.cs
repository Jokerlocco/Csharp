﻿// Galaxian SDL

// Version + Date   Author + Changes
// --------------   --------------------------------------
// 009, 21-Feb-19   Nacho: Empty skeleton

class LoadingScreen
{
    public LoadingScreen()
    {
    }

    public void Run()
    {
        // TO DO: Display Logo for 3 seconds and then finish
    }
}

