﻿// Galaxian SDL

// Version + Date   Author + Changes
// --------------   --------------------------------------
// 009, 21-Feb-19   Nacho: Empty skeleton

class CreditsScreen
{
    public CreditsScreen()
    {
    }

    public void Run()
    {
        // TO DO: Display names of the developers. Wait for R to return.
    }
}

