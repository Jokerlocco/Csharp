﻿class Toldo : Persiana
{
    public Toldo(byte posicion, string nombre) : base(posicion, nombre)
    {
        
    }


}