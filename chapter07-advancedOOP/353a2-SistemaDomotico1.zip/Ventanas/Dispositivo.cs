﻿abstract class Dispositivo
{
    protected string nombre;

    public Dispositivo(string nombre) { this.nombre = nombre; }

    public void SetNombre(string nombre) { this.nombre = nombre; }

    public override string ToString()
    {
        return "Nombre: " + nombre;
    }
}

