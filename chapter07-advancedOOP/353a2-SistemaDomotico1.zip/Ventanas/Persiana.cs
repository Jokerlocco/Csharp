﻿using System;

class Persiana : Dispositivo
{
    protected byte posicion;

    public byte GetPosicion() { return posicion; }

    public Persiana(byte posicion, string nombre) : base(nombre)
    {
        this.posicion = posicion;
    }

    public void Subir()
    {
        posicion = 100;
    }

    public void Bajar()
    {
        posicion = 0;
    }

    public void Subir(byte porcentaje)
    {
        posicion += porcentaje;
    }

    public void Bajar(byte porcentaje)
    {
        posicion -= porcentaje;
    }

    public void Abrir(byte posicion)
    {
        this.posicion = posicion;
    }

    public override string ToString()
    {
        return base.ToString() + ", Posicion: " + posicion;
    }
}
