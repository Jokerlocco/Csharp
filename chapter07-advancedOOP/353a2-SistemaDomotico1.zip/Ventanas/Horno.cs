﻿class Horno : CosaQueCalienta
{

    public Horno(bool encendido, int temperatura, string nombre)
        : base(encendido, temperatura, nombre)
    {

    }

    public Horno(int temperatura, string nombre) : this(false, temperatura, nombre)
    {

    }

}