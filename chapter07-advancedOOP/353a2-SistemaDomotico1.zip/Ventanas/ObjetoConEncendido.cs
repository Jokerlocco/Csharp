﻿
class ObjetoConEncendido : Dispositivo
{
    protected bool encendido;

    public ObjetoConEncendido(bool encendido, string nombre) : base(nombre)
    {
        this.encendido = encendido;
    }

    public bool GetEncendido() { return encendido; }

    public void Encender() { encendido = true; }
    public void Apagar() { encendido = false; }

    public override string ToString()
    {
        return base.ToString() + ", Estado: " + encendido;
    }
}

