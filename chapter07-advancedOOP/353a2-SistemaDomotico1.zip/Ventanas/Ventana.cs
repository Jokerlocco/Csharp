﻿class Ventana : Dispositivo
{
    protected Persiana p;

    public Ventana(Persiana p, string nombre) : base(nombre)
    {
        this.p = p;
    }

    public Persiana GetPersiana() { return p; }

    public override string ToString()
    {
        return base.ToString() + ", Persiana en: " + p.GetPosicion();
    }
}