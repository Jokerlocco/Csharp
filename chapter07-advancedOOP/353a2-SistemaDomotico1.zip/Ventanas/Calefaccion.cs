﻿class Calefaccion : CosaQueCalienta
{
    
    public Calefaccion(bool encendido, int temperatura, string nombre) 
        : base(encendido, temperatura, nombre)
    {
        
    }

    public Calefaccion(int temperatura, string nombre) 
        : this(false, temperatura, nombre)
    {

    }

}