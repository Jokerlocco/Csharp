﻿class PuertaGaraje : Puerta
{
    protected byte posicion;

    public PuertaGaraje(bool bloqueda, byte posicion, string nombre) 
        : base(bloqueda, nombre)
    {
        this.posicion = posicion;
    }

    //public byte GetPosicion() { return posicion; }

    public void Subir()
    {
        posicion = 100;
    }

    public void Bajar()
    {
        posicion = 0;
    }

    public void Subir(byte porcentaje)
    {
        posicion += porcentaje;
    }

    public void Bajar(byte porcentaje)
    {
        posicion -= porcentaje;
    }

    public override string ToString()
    {
        return base.ToString() + ", Posicion: " + posicion;
    }
}