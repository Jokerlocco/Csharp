﻿class Luz : ObjetoConEncendido
{
    public Luz(bool encendido, string nombre) : base(encendido, nombre)
    {
        
    }


}

