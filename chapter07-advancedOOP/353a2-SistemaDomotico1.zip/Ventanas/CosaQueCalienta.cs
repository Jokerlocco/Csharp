﻿class CosaQueCalienta : Dispositivo
{
    protected int temperatura;
    protected bool encendido;

    public CosaQueCalienta(bool encendido, int temperatura, string nombre) 
        : base(nombre)
    {
        this.temperatura = temperatura;
        this.encendido = encendido;
    }

    public CosaQueCalienta(int temperatura, string nombre) 
        : this(false, temperatura, nombre)
    {

    }

    public bool GetEncendido() { return encendido; }
    public int GetTemperatura() { return temperatura; }

    public void SetTemperatura(int temperatura) 
    { 
        this.temperatura = temperatura; 
    }

    public void Encender() { encendido = true; }
    public void Apagar() { encendido = false; }



    public override string ToString()
    {
        return base.ToString() + ", Temperatura: " + temperatura 
                   + ", Encendido: " + encendido;
    }
}

