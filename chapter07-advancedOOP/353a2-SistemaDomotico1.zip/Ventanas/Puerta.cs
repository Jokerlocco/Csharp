﻿class Puerta : Dispositivo
{
    protected bool bloqueada;

    public Puerta(bool bloqueada, string nombre) : base(nombre)
    {
        this.bloqueada = bloqueada;
    }

    public void Desbloquear()
    {
        bloqueada = false;
    }

    public void Bloquear()
    {
        bloqueada = true;
    }
    
    public bool GetBloqueada()
    {
        return bloqueada;
    }

    public override string ToString()
    {
        return base.ToString() + ", Bloqueo: " + bloqueada;
    }
}
