﻿class AspiradorRobotico : ObjetoConEncendido
{
    protected byte bateria;

    public AspiradorRobotico(bool encendido, string nombre) 
        : base(encendido, nombre)
    {
        bateria = 75;
    }

   
    public byte GetBateria() { return bateria; }


    public override string ToString()
    {
        return base.ToString() + ", Bateria: " + bateria;
    }
}

