﻿// Ivan Lazcano

using System;

class Game
{ 
    const int CANTBOLAS = 14;
    const int CANTCOPITOS = 25;
    const int ANCHO = 1024;
    const int ALTO = 700;
    static Font xmas;
    static Image tree;
    static Image imgBola;//60x60
    static Image snowflake;//25x28
    static string text;
    static int countText;
    static bool end;
    static bool transicionTexto;
    static int countPause;
    static int pauseTime;
    static int BolasVisibles;

    static Bolas[] bola = new Bolas[CANTBOLAS];
    static Snowflakes[] copito = new Snowflakes[CANTCOPITOS];
    static Random rnd;


    struct Snowflakes
    {
        public int x;
        public int y;
        public bool visible;
    }


    struct Bolas
    {
        public bool visible;
        public int x;
        public int y;
        public float vy;
        public float vx;
    }

    static void Init()
    {
        bool fullScreen = false;
        SdlHardware.Init(ANCHO, ALTO, 24, fullScreen);

        xmas = new Font("data/xmas.ttf", 104);
        tree = new Image("data/tree.jpg");
        imgBola = new Image("data/bola.png");
        snowflake = new Image("data/snowflake.png");
        text = "Feliz 2019!";
        countText = 1;
        end = false;
        rnd = new Random();
        transicionTexto = true;
        countPause = 0;
        pauseTime = 40;

        for (int i = 0; i < CANTBOLAS; i++)
        {
            bola[i].visible = false;
        }
        BolasVisibles = 0;

        for (int i = 0; i < CANTCOPITOS; i++)
        {
            copito[i].visible = false;
        }
        InitCopito(0);
    }

    static void MoveBalls()
    {
        for (int i = 0; i < CANTBOLAS; i++) 
        {
            if(bola[i].visible)
            {
                bola[i].x += (int)bola[i].vx;
                bola[i].y += (int)bola[i].vy;
                if(bola[i].x < 0 || bola[i].x > ANCHO - 60)
                {
                    bola[i].vx = -bola[i].vx;
                }
                if (bola[i].y < 0 || bola[i].y > ALTO - 60)
                {
                    bola[i].vy = -bola[i].vy;
                }
            }
        }
    }


    static void InitBalls()
    {
        //No cumple con el cada 5 segundos 1 bola nueva, pero así
        //me gusta más, el chorro de bolas saliendo simplemente me encanta
        if(!transicionTexto && BolasVisibles < CANTBOLAS)
        {
            bola[BolasVisibles].x = BolasVisibles % 2 == 0 ? 0 : ANCHO-60;
            bola[BolasVisibles].y = ALTO/2;
            bola[BolasVisibles].vx = rnd.Next(10, 15);
            bola[BolasVisibles].vy = 
                BolasVisibles % 3 == 0 ? rnd.Next(10,15) : rnd.Next(-15, -10);
            bola[BolasVisibles].visible = true;
            BolasVisibles++;
        }
    }


    static void InitCopito(int i)
    {
        copito[i].visible = true;
        copito[i].y = 0;
        copito[i].x = rnd.Next(0, ANCHO - 30);
    }


    static void MoverCopitos()
    {
        for (int i = 0; i < CANTCOPITOS; i++)
        {
            if(copito[i].visible)
            {
                copito[i].y += 20;
                if(copito[i].y > ALTO-28)
                {
                    copito[i].y = 0;
                    copito[i].x = rnd.Next(0, ANCHO - 30);
                }
                if ((i + 1 < CANTCOPITOS) && !copito[i + 1].visible &&
                    copito[i].y > ALTO/10)
                    InitCopito(i + 1);
            }
        }
    }

    static void DrawElements()
    {
        SdlHardware.ClearScreen();
        SdlHardware.DrawHiddenImage(tree, 0, 0);

        if (transicionTexto)
        {
            if (countPause < 4)
            {
                SdlHardware.WriteHiddenText(text.Substring(0, countText),
                                            260, 50, 248, 0, 0, xmas);
                countPause++;
            }
            else
            {
                SdlHardware.WriteHiddenText(text.Substring(0, countText),
                                            260, 50, 248, 0, 0, xmas);
                countText++;
                if ((countText >= text.Length))
                    transicionTexto = false;
                countPause = 0;
            }
        }
        else
            SdlHardware.WriteHiddenText(text, 260, 50, 248, 0, 0, xmas);

        for (int i = 0; i < CANTBOLAS; i++)
        {
            if(bola[i].visible)
                SdlHardware.DrawHiddenImage(imgBola, bola[i].x, bola[i].y);
        }

        for (int i = 0; i < CANTCOPITOS; i++)
        {
            if(copito[i].visible)
                SdlHardware.DrawHiddenImage(snowflake, copito[i].x, copito[i].y);
        }
        
        SdlHardware.ShowHiddenScreen();
    }


    static void Pause( int time = 40)
    {
        SdlHardware.Pause(time);
    }


    static void ProcesInput()
    {
        if (SdlHardware.KeyPressed(SdlHardware.KEY_SPC) ||
            SdlHardware.KeyPressed(SdlHardware.KEY_ESC))
            end = true;
        if (SdlHardware.KeyPressed(SdlHardware.KEY_RIGHT))
            pauseTime = pauseTime <= 5 ? pauseTime : pauseTime-5;
        if (SdlHardware.KeyPressed(SdlHardware.KEY_LEFT))
            pauseTime += 5;
           
    }


    static void Main(string[] args)
    {
        Init();
        do
        {
            MoveBalls();
            MoverCopitos();
            InitBalls();
            DrawElements();
            ProcesInput();
            Pause(pauseTime);
        } while (!end);
    }
}

